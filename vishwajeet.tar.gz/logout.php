<?php
require "var.inc.php" ;
session_destroy();
header("Location: index.php");

?>